import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {DbDataSource} from '../datasources';
import {ViajesTerrestres, ViajesTerrestresRelations} from '../models';

export class ViajesTerrestresRepository extends DefaultCrudRepository<
  ViajesTerrestres,
  typeof ViajesTerrestres.prototype.id,
  ViajesTerrestresRelations
> {
  constructor(
    @inject('datasources.db') dataSource: DbDataSource,
  ) {
    super(ViajesTerrestres, dataSource);
  }
}
