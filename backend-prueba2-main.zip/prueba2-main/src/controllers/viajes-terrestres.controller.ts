import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where,
} from '@loopback/repository';
import {
  post,
  param,
  get,
  getModelSchemaRef,
  patch,
  put,
  del,
  requestBody,
  response,
} from '@loopback/rest';
import {ViajesTerrestres} from '../models';
import {ViajesTerrestresRepository} from '../repositories';

export class ViajesTerrestresController {
  constructor(
    @repository(ViajesTerrestresRepository)
    public viajesTerrestresRepository : ViajesTerrestresRepository,
  ) {}

  @post('/viajes-terrestres')
  @response(200, {
    description: 'ViajesTerrestres model instance',
    content: {'application/json': {schema: getModelSchemaRef(ViajesTerrestres)}},
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ViajesTerrestres, {
            title: 'NewViajesTerrestres',
            exclude: ['id'],
          }),
        },
      },
    })
    viajesTerrestres: Omit<ViajesTerrestres, 'id'>,
  ): Promise<ViajesTerrestres> {
    return this.viajesTerrestresRepository.create(viajesTerrestres);
  }

  @get('/viajes-terrestres/count')
  @response(200, {
    description: 'ViajesTerrestres model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(ViajesTerrestres) where?: Where<ViajesTerrestres>,
  ): Promise<Count> {
    return this.viajesTerrestresRepository.count(where);
  }

  @get('/viajes-terrestres')
  @response(200, {
    description: 'Array of ViajesTerrestres model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(ViajesTerrestres, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(ViajesTerrestres) filter?: Filter<ViajesTerrestres>,
  ): Promise<ViajesTerrestres[]> {
    return this.viajesTerrestresRepository.find(filter);
  }

  @patch('/viajes-terrestres')
  @response(200, {
    description: 'ViajesTerrestres PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ViajesTerrestres, {partial: true}),
        },
      },
    })
    viajesTerrestres: ViajesTerrestres,
    @param.where(ViajesTerrestres) where?: Where<ViajesTerrestres>,
  ): Promise<Count> {
    return this.viajesTerrestresRepository.updateAll(viajesTerrestres, where);
  }

  @get('/viajes-terrestres/{id}')
  @response(200, {
    description: 'ViajesTerrestres model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(ViajesTerrestres, {includeRelations: true}),
      },
    },
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(ViajesTerrestres, {exclude: 'where'}) filter?: FilterExcludingWhere<ViajesTerrestres>
  ): Promise<ViajesTerrestres> {
    return this.viajesTerrestresRepository.findById(id, filter);
  }

  @patch('/viajes-terrestres/{id}')
  @response(204, {
    description: 'ViajesTerrestres PATCH success',
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ViajesTerrestres, {partial: true}),
        },
      },
    })
    viajesTerrestres: ViajesTerrestres,
  ): Promise<void> {
    await this.viajesTerrestresRepository.updateById(id, viajesTerrestres);
  }

  @put('/viajes-terrestres/{id}')
  @response(204, {
    description: 'ViajesTerrestres PUT success',
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() viajesTerrestres: ViajesTerrestres,
  ): Promise<void> {
    await this.viajesTerrestresRepository.replaceById(id, viajesTerrestres);
  }

  @del('/viajes-terrestres/{id}')
  @response(204, {
    description: 'ViajesTerrestres DELETE success',
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.viajesTerrestresRepository.deleteById(id);
  }
}
