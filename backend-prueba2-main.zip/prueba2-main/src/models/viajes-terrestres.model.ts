import {Entity, model, property} from '@loopback/repository';

@model()
export class ViajesTerrestres extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: true,
  })
  id?: string;

  @property({
    type: 'string',
  })
  descripcion?: string;

  @property({
    type: 'string',
  })
  puntoInicial?: string;

  @property({
    type: 'string',
  })
  puntoFinal?: string;

  @property({
    type: 'number',
  })
  distancia?: number;

  @property({
    type: 'boolean',
  })
  finalizado?: boolean;

  constructor(data?: Partial<ViajesTerrestres>) {
    super(data);
  }
}

export interface ViajesTerrestresRelations {
  // describe navigational properties here
}

export type EviajesTerrestresWithRelations = ViajesTerrestres & ViajesTerrestresRelations;
